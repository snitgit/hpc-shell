---
layout: reference
permalink: /reference/
---

## Glossary

## External References

### Text Editing

* [Nano editor home page](https://www.nano-editor.org/)

  - [Nano tutorial](https://www.howtoforge.com/linux-nano-command/)

* [VIM editor home page](https://www.vim.org/)

  - Vim also has a built-in tutorial. From the bash prompt, type `vimtutor`
    and follow the instructions.


